#include <stdio.h>
#include <stdlib.h>

struct nd {
    int data;
    struct nd* next;
};

struct q {
    struct nd* front;
    struct nd* rear;
    int size;
};

struct q* initialise() {
    struct q* q = (struct q*)malloc(sizeof(struct q));
    q->front = NULL;
    q->rear = NULL;
    q->size = 0;
    return q;
}

void enqueue(struct q* q, int value) {
    struct nd* ptr = (struct nd*)malloc(sizeof(struct nd));
    ptr->data = value;
    ptr->next = NULL;

    if (q->rear == NULL) {
        q->front = ptr;
        q->rear = ptr;
    } else {
        q->rear->next = ptr;
        q->rear = ptr;
    }

    q->size++;
}

int dequeue(struct q* q) {
    if (q->front == NULL) {
        printf(" empty\n");
        return -1;
    }

    int value = q->front->data;
    struct nd* temp = q->front;

    if (q->front == q->rear) {
        q->front = NULL;
        q->rear = NULL;
    } else {
        q->front = q->front->next;
    }

    free(temp);
    q->size--;
    return value;
}

int front(struct q* q) {
    if (q->front == NULL) {
        printf(" empty\n");
        return -1;
    }

    return q->front->data;
}

int size(struct q* q) {
    return q->size;
}

void print(struct q* q) {
    struct nd* current = q->front;
    while (current != NULL) {
        printf("%d ", current->data);
        current = current->next;
    }
    printf("\n");
}

int main() {
    struct q* q = initialise();
    int choice, val;

    printf("Enter capacity of queue: \n");
    int cap;
    scanf("%d", &cap);

    while (1) {
                    
        printf("Enter 1 for ENQUE \n");
        printf("Enter 3 for FRONT  \n");
        printf("Enter 4 to SIZE   \n");

        printf("Enter 2 for DEQUE  \n");

        printf("Enter 5 to PRINT QUEUE  \n");
        printf("Enter 6 to Exit   \n");
        scanf("%d",&choice);

        switch (choice) {
            case 1:
                printf("Enter value to enqueue: ");
                scanf("%d", &val);
                enqueue(q, val);
                break;
            case 2:
                printf("\n");
                int poppedValue = dequeue(q);
                if (poppedValue != -1) {
                    printf("Dequeued value: %d\n", poppedValue);
                }
                break;
            case 3:
                printf("\n");
                int frontValue = front(q);
                if (frontValue != -1) {
                    printf("Front of queue is: %d\n", frontValue);
                }
                break;
            case 4:
                printf("\n");
                int queueSize = size(q);
                printf("Size of queue is %d\n\n", queueSize);
                break;
            case 5:
                print(q);
                break;
            case 6:
                return 0;
            default:
                printf("\nInvalid , try again:\n");
        }
    }

    return 0;
}
