#include <stdio.h>
#include<stdlib.h>

struct queue {
    int *ar;
    int capacity, front, rear,size;
};



struct queue* initialise(int cap) {
    struct queue* ptr = (struct queue*)malloc(sizeof(struct queue));
    ptr->capacity=cap;

    ptr->front = -1;
    ptr->rear = -1;
    ptr -> size = 0; 
    ptr->ar = (int *)malloc(sizeof(int) * cap);
    return ptr;
}

void enque(struct queue* q1, int value){
    if(q1->size == q1->capacity){
        printf("Queue full\n");
        return ;
    }
    q1->ar[q1->rear] = value;
    q1->rear = (q1->rear + 1)% q1->capacity;
    
    q1->size++;

}

int deque(struct queue*q1){
    if(q1->size ==0){
        printf("empty  ");
        return 0;

    }
    int val = (q1->ar[q1->front]);
    q1-> front = (q1->front + 1)%q1->capacity;
    q1->size--;
    return val; 
}

void print(struct queue* q1) {
    if (q1->size ==0) {
        printf(" empty\n");
        return;
    }
    int i = q1->front;
    do {
        printf("%d ", q1->ar[i]);
        i = (i + 1) % q1->capacity; 
    } while (i != (q1->rear + 1) % q1->capacity);
    printf("\n");
}





int main(){

    
    int choice,val;
    printf("Enter capacity of queue : \n");
                int cap;
                scanf("%d",&cap);
                struct queue* q1= initialise(cap);
                while (1) {
                    
                    printf("Enter 1 for ENQUE \n");
                    printf("Enter 2 for DEQUE  \n");
                    printf("Enter 3 for FRONT  \n");
                    printf("Enter 4 to SIZE   \n");
                    printf("Enter 5 to PRINT QUEUE  \n");
                    printf("Enter 6 to Exit   \n");
                    scanf("%d",&choice);
                    switch (choice)
                    {
                    case 1:
                        printf("Enter value to push :");
                        scanf("%d",&val);
                        enque(q1,val);
                        break; 
                    case 2:
                    
                        printf("\n");    
                        int poppedvalue = deque(q1);
                        printf("popped value : %d \n",poppedvalue);
                        break; 
                        
                    
                    case 3:
                        printf("\n");
                        int top = q1->ar[q1->front];
                        printf("FRONT of queue is   %d \n", top);
                        break; 
                    case 5:
                        print(q1);
                        break; 
                    case 4:
                        printf("\n");
                        int size = (q1->size) + 1;
                        printf("\n");
                        printf("Size of queue is %d \n\n",size);
                        break;
                    case 6:
                        return 0;
                    default:
                        printf("\n\n invalid , try again  \n\n");
                    
                    
                    
                    
                    
                    }
                }





}