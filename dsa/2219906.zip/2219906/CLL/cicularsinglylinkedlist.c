#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node* next;
};

struct node* createNode(int val) {
    struct node* newNode = (struct node*)malloc(sizeof(struct node));
    newNode->data = val;
    newNode->next = NULL;
    return newNode;
}

void insertBegin(struct node** head, int val) {
    struct node* newNode = createNode(val);

    if (*head == NULL) {
        newNode->next = newNode; 
        *head = newNode;
    } else {
        struct node* temp = *head;
        while (temp->next != *head) {
            temp = temp->next;
        }
        temp->next = newNode;
        newNode->next = *head;
        *head = newNode;
    }
}

void printCircularList(struct node* head) {
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }
    struct node* current = head;
    do {
        printf("%d ", current->data);
        current = current->next;
    } while (current != head);
    printf("\n");
}

void insertEnd(struct node** head, int val) {
    struct node* newNode = createNode(val);

    if (*head == NULL) {
        newNode->next = newNode; 
        *head = newNode;
    } else {
        struct node* temp = *head;
        while (temp->next != *head) {
            temp = temp->next;
        }
        temp->next = newNode;
        newNode->next = *head;
    }
}

void insertAfter(struct node* head, int k, int val) {
    struct node* newNode = createNode(val);
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }
    struct node* current = head;
    while (current->data != k && current->next != head) {
        current = current->next;
    }
    if (current->data != k) {
        printf("Element %d not found\n", k);
        return;
    }
    newNode->next = current->next;
    current->next = newNode;
}

void deleteBegin(struct node** head) {
    if (*head == NULL) {
        printf("List is empty\n");
        return;
    }
    struct node* temp = *head;
    struct node* current = *head;

    if (temp->next == *head) {
        *head = NULL;
    } else {
        while (current->next != *head) {
            current = current->next;
        }
        *head = temp->next;
        current->next = *head;
    }
    free(temp);
}

void deleteEnd(struct node** head) {
    if (*head == NULL) {
        printf("empty list\n");
        return;
    }
    struct node* current = *head;
    struct node* temp = NULL;

    while (current->next != *head) {
        temp = current;
        current = current->next;
    }

    if (current == *head) {
        *head = NULL;
    } else {
        temp->next = *head;
    }

    free(current);
}

void deleteAtK(struct node** head, int k) {
    if (*head == NULL) {
        printf("empty list\n");
        return;
    }

    struct node* current = *head;
    struct node* prev = NULL;

    while (current->data != k && current->next != *head) {
        prev = current;
        current = current->next;
    }

    if (current->data != k) {
        printf("Element %d not found\n", k);
        return;
    }

    if (current->next == *head) {
        *head = NULL;
    } else {
        prev->next = current->next;
    }

    free(current);
}

int main() {
    struct node* head = NULL;
    int choice, val;

    printf("MENU DRIVEN\n");
    while (1) {
        printf("\nMenu:\n");
        printf("1.insert at beginning\n");
        printf("2.insert at end\n");
        printf("3. insert after node\n");
        printf("4. delete from beginning\n");
        printf("5. delete from end\n");
        printf("6. delete node\n");
        printf("7. print list\n");
        printf("8. exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        
        switch (choice) {
            case 1:
                printf("Enter value to insert at beginning: ");
                scanf("%d", &val);
                insertBegin(&head, val);
                break;
            case 2:
                printf("Enter value to insert at end: ");
                scanf("%d", &val);
                insertEnd(&head, val);
                break;
            case 3:
                printf("Enter value to insert after: ");
                int k;
                scanf("%d", &k);
                printf("Enter value to insert: ");
                scanf("%d", &val);
                insertAfter(head, k, val);
                break;
            case 4:
                deleteBegin(&head);
                break;
            case 5:
                deleteEnd(&head);
                break;
            case 6:
                printf("Enter value to delete: ");
                scanf("%d", &k);
                deleteAtK(&head, k);
                break;
            case 7:
                printCircularList(head);
                break;
            case 8:
                return 0;
            default:
                printf("Invalid choice, try again\n");
        }
    }

    return 0;
}
