

#include <stdio.h>
#include<stdlib.h>




struct nodedouble {
    int data;
    struct nodedouble* next;
    struct nodedouble* prev;
};





void insertbegin(struct nodedouble** head, int val) {
    struct nodedouble* ptr = (struct nodedouble*)malloc(sizeof(struct nodedouble));
    ptr->data = val;
    if (!(*head)) {
        ptr->next = ptr; 
        ptr->prev = ptr; 
    } else
     {
        ptr->next = *head;
        ptr->prev = (*head)->prev;
        (*head)->prev->next = ptr;
        (*head)->prev = ptr;
    }
    *head = ptr;
}









void printcircular(struct nodedouble** head) {
    if (!(*head)) {
        printf("empty\n");
        return;
    }
    struct nodedouble* itr = (*head);
    do {
        printf("%d ", itr->data);
        printf("\t");
        itr = itr->next;
    } while (itr != (*head)); 
    printf("\n");
}







void insertend(struct nodedouble** head, int val) {
    struct nodedouble* ptr = (struct nodedouble*)malloc(sizeof(struct nodedouble));
    ptr->data = val;
    if (!(*head)) {
        ptr->next = ptr; 
        ptr->prev = ptr; 
        *head = ptr;
        return;
    }
    struct nodedouble* last = (*head)->prev; 
    ptr->next = *head;
    ptr->prev = last;
    last->next = ptr;
    (*head)->prev = ptr;
}

void insertafter(struct nodedouble** head, int k, int val) {
    struct nodedouble* ptr= (struct nodedouble*)malloc(sizeof(struct nodedouble));
    ptr->data = val;
    if (!(*head)) {
        printf("empty\n");
        return;
    }
    struct nodedouble* itr = *head;
    while (itr->data != k && itr->next != (*head)) {
        itr = itr->next;
    }
    ptr->next = itr->next;
    ptr->prev = itr;
    itr->next->prev = ptr;
    itr->next = ptr;
}






void deletebegin(struct nodedouble** head) {
    if (!(*head)) {
        printf("empty\n");
        return;
    }
    struct nodedouble* ptr = *head;
    if (ptr->next == ptr) {
        *head = NULL;
    } else {
        ptr->next->prev = ptr->prev;
        ptr->prev->next = ptr->next;
        *head = ptr->next;
    }
    free(ptr);
}




void deleteend(struct nodedouble** head) {
    if (!(*head)) {
        printf("empty\n");
        return;
    }
    struct nodedouble* ptr = *head;
    if (ptr->next == ptr) {
        *head = NULL; 
    } else {
        ptr = ptr->prev;
        ptr->prev->next = ptr->next;
        ptr->next->prev = ptr->prev;
    }
    free(ptr);
}





void deleteatkcircularlylinked(struct nodedouble** head, int k) {
    if (!(*head)) {
        printf("empty\n");
        return;
    }
    struct nodedouble* ptr = *head;
    while (ptr->data != k && ptr->next != (*head)) {
        ptr = ptr->next;
    }
    if (ptr->data != k) {
        printf("Element %d does not found\n", k);
        return;
    }
    if (ptr->next == ptr) {
        *head = NULL; 
    } else {
        ptr->prev->next = ptr->next;
        ptr->next->prev = ptr->prev;
        if (ptr == *head) {
            *head = ptr->next;
        }
    }
    free(ptr);
}



int main(){

    struct nodedouble* dhead = NULL;
    int choice,val;

    printf("THIS IS A MENU DRIVEN PROGRAM :\n");
    while (1) {
        printf("\nMenu:\n");
        printf("1.insert at beginning\n");
        printf("2.insert at end\n");
        printf("3.insert after node\n");
        printf("4.delete from beginning\n");
        printf("5.delete from end\n");
        printf("6.delete node\n");
        printf("7. Print  list\n");
        printf("8. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                printf("enter value to insert: ");
                int val;
                scanf("%d", &val);
                insertbegin(&dhead, val);
                break;
            case 2:
                printf("enter value to insert: ");
                scanf("%d", &val);
                insertend(&dhead, val);
                break;
            case 3:
                printf("enter value to insert after: ");
                int k;
                scanf("%d", &k);
                printf("enter value to insert: ");
                scanf("%d", &val);
                insertafter(&dhead, k, val);
                break;
            case 4:
                deletebegin(&dhead);
                break;
            case 5:
                deleteend(&dhead);
                break;
            case 6:
                printf("enter value to delete: ");
                scanf("%d", &k);
                deleteatkcircularlylinked(&dhead, k);
                break;
            case 7:
                printcircular(&dhead);
                break;
            case 8:
                return 0;
            default:
                printf("invalid, try again\n");
        }
    }

}

