#include <stdio.h>
#include<stdlib.h>


struct stack {
    struct node* head;
    int size;
}s1;

struct node{
    int data;
    struct node* next;

};



void initialise(struct stack* s1) {
    s1->head= NULL;
    s1->size = 0;

    return ;

}
void push(struct stack *s1, int value) {
    struct node* ptr = (struct node*)malloc(sizeof(struct node));
    ptr ->data =value ;
    ptr->next = s1->head;
    s1->head = ptr;
    s1->size++;
}

int popliststack(struct stack *s1) {
    if(s1->size == 0){
        printf("empty \n");
        return 0;
    }
    int value = s1->head->data;
    s1->head = s1->head->next;
    s1->size--;
    return value;

}

void print(struct stack *s1) {
    if (s1->size == 0){
        printf("empty  \n ");
        return ;

    }
    struct node* ptr = s1->head;
    while(ptr){
        printf("%d  \t", ptr->data);
        ptr= ptr->next;
    }
    printf("\n");
}

int toplist(struct stack *s1) {
    if(s1->size == 0){
        printf("empty   \n");
        return 0;
    }
    return s1->head->data;

}

int sizeliststack(struct stack *s1){
    if(s1->size == 0){
        printf("empty   \n");
        return 0;
    }
    return   s1-> size;
}


int main(){

    
    struct stack s;
    int choice,value;
    initialise(&s);
                    while (1) {
                        
                        printf("Enter 1 for PUSH \n");
                        printf("Enter 2 for POP   \n");
                        printf("Enter 3 for TOP   \n");
                        printf("Enter 4 to PRINT   \n");
                        printf("Enter 5 to SIZE   \n");
                        printf("Enter 6 to Exit   \n");
                        scanf("%d",&choice);
                        switch (choice)
                        {
                        case 1:
                            printf("Enter value to push :");
                            scanf("%d",&value);
                            push(&s,value);
                            break; 
                        case 2:
                        
                            printf("\n");    
                            int poppedvalue = popliststack(&s);
                            printf("popped value : %d \n",poppedvalue);
                            break; 
                            
                        
                        case 3:
                            printf("\n");
                            int top = toplist(&s);
                            printf("TOP of  stack   : %d \n", top);
                            break; 
                        case 4:
                            print(&s);
                            break; 
                        case 5:
                            printf("\n");
                            int size = sizeliststack(&s);
                            printf("\n");
                            printf("Size of stack   %d \n\n",size);
                            break;
                        case 6:
                            return 0;
                        default:
                            printf("\n\n invalid   , try again : \n\n");
                        
                        
                        
                        
                    
                        }
                    }


}
