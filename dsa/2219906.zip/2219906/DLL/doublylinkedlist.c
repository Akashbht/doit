
#include <stdio.h>
#include<stdlib.h>



struct nodedouble {
    int data;
    struct nodedouble* next;
    struct nodedouble* prev;
};



void insertbegin(struct nodedouble** head, int val) {
    struct nodedouble* ptr = (struct nodedouble*)malloc(sizeof(struct nodedouble));
    ptr->data = val;
    ptr->prev = NULL;
    if (!(*head)) {
        ptr->next = NULL; 
    } else {
        ptr->next = *head;
        (*head)->prev = ptr;
    }
    *head = ptr;
}

void printlist(struct nodedouble** head){
    if(!(*head)){
        printf("List is empty\n");
        return;
    }
    struct nodedouble* itr = (*head);
    while(itr!= NULL ){
        

        printf("%d ",itr->data );
        printf("\t");
        itr = itr->next;
        
    }
};




void insertend(struct nodedouble** head, int val) {
    struct nodedouble* ptr = (struct nodedouble*)malloc(sizeof(struct nodedouble));
    ptr->data = val;
    ptr->next = NULL;
    if (!(*head)) {
        ptr->prev = NULL; 
        *head = ptr;
        return;
    }
    struct nodedouble* itr = *head;
    while (itr->next) {
        itr = itr->next;
    }
    itr->next = ptr;
    ptr->prev = itr;
}


void insertafter(struct nodedouble** head, int k, int val) {
    struct nodedouble* ptr = (struct nodedouble*)malloc(sizeof(struct nodedouble));
    ptr->data = val;
    ptr->next = NULL;
    ptr->prev = NULL;
    if (!(*head)) {
        printf("empty\n");
        return;
    }
    struct nodedouble* itr = *head;
    while (itr->data != k && itr->next) {
        itr = itr->next;
    }
    ptr->next = itr->next;
    ptr->prev = itr;
    if (itr->next) {
        itr->next->prev = ptr;
    }
    itr->next = ptr;
}





struct nodedouble* createdoublenode(int data) {
    struct nodedouble* ptr = (struct nodedouble*)malloc(sizeof(struct nodedouble));
    if (ptr == NULL) {
        printf("allocation failed\n");
        return NULL;
    }
    ptr->data = data;
    ptr->next = NULL;
    ptr->prev = NULL;
    return ptr;
}

void deletebegin(struct nodedouble** head) {
    if (!head || !(*head)) {
        printf("empty\n");
        return;
    }
    struct nodedouble* ptr = *head;
    *head = (*head)->next;
    if (*head) {
        (*head)->prev = NULL;
    }
    free(ptr);
}

void deleteend(struct nodedouble** head) {
    if (!head || !(*head)) {
        printf("empty\n");
        return;
    }
    struct nodedouble* itr = (*head);
    while (itr->next != NULL) {
        itr = itr->next;
    }
    if (itr->prev) {
        itr->prev->next = NULL;
    } else {
        *head = NULL;
    }
    free(itr);
}

void deleteatkdoublylinked(struct nodedouble** head, int k) {
    if (!head || !(*head)) {
        printf("empty\n");
        return;
    }
    struct nodedouble* itr = (*head);
    while (itr != NULL && itr->data != k) {
        itr = itr->next;
    }
    if (!itr) {
        printf("Element %d not found\n", k);
        return;
    }
    if (itr->prev) {
        itr->prev->next = itr->next;
    } else {
        *head = itr->next;
    }
    if (itr->next) {
        itr->next->prev = itr->prev;
    }
    free(itr);
}





int main(){

    struct nodedouble* dhead = NULL;
    int choice,val;



    while (1) {
            printf("\nMenu:\n");
            printf("1.insert at beginning\n");
            printf("2.insert at end\n");
            printf("3.insert after node\n");
            printf("4.delete from beginning\n");
            printf("5.delete from end\n");
            printf("6.delete node\n");
            printf("7. Print  list\n");
            printf("8. Exit\n");
            printf("Enter your choice: ");
            scanf("%d", &choice);
            switch (choice) {
                case 1:
                    printf("Enter the value to insert: ");
                    int val;
                    scanf("%d", &val);
                    insertbegin(&dhead, val);
                    break;
            case 2:
                printf("Enter the value to insert: ");
                scanf("%d", &val);
                insertend(&dhead, val);
                break;
            case 3:
                printf("Enter the value to insert after: ");
                int k;
                scanf("%d", &k);
                printf("Enter the value to insert: ");
                scanf("%d", &val);
                insertafter(&dhead, k, val);
                break;
            case 4:
                deletebegin(&dhead);
                break;
            case 5:
                deleteend(&dhead);
                break;
            case 6:
                printf("Enter the value to delete: ");
                scanf("%d", &k);
                deleteatkdoublylinked(&dhead, k);
                break;
            case 7:
                printlist(&dhead);
                break;
            case 8:
                return 0;
            default:
                printf("Invalid, try again\n");
        }
    }    


}
