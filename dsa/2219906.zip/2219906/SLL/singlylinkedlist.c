#include <stdio.h>
#include<stdlib.h>



struct node{
    int data;
    struct node* next;

};




void insertbegin(struct node** head, int val){
    struct node* ptr = (struct node*)malloc(sizeof(struct node));
    
    ptr->data=val;
    ptr->next=NULL;
    if (!head){
        
        *head = ptr;
        return;
    }
    ptr -> next=(*head);
    (*head) = ptr;
    
    
};

void insertatendsinglylinked(struct node** head, int val){
    struct node* ptr = (struct node*)malloc(sizeof(struct node));
    ptr->data=val;
    ptr->next=NULL;
    if (!head){
        *head = ptr;
        return;
    }
    struct node* itr =  *head;
    while(itr->next){
        itr = itr -> next;
    }
    itr->next = ptr;

};

void insertafter(struct node** head,int k, int val){
    struct node* ptr = (struct node*)malloc(sizeof(struct node));
    ptr->data=val;
    ptr->next=NULL;
    if (!head){
        *head = ptr;
        return;
    }
    struct node* itr =  *head;
    while(itr->data!=k && (itr->next)){
        itr = itr -> next;
    }
    ptr->next = itr->next;
    itr->next = ptr;

};


void printlist(struct node** head){
    printf("\n\n");
    if(!head){
        printf("empty\n");
        return;
    }
    struct node* itr = (*head);
    while(itr!= NULL ){
        

        printf("%d ",itr->data );
        printf("\t");
        itr = itr->next;
        
    }
    printf("\n\n");
};


void deletebegin(struct node** head){
    if((*head)==NULL ||(*head)->next==NULL ){
        (*head) = NULL;
        return;
    }
    (*head) = (*head)-> next;
    return;
}

void deleteatk(struct node** head, int k){
    if((*head)==NULL ||(*head)->next==NULL ){
        (*head) = NULL;
        return;
    }
    struct node* itr = (*head);
    while((itr -> next )-> data != k ){
        itr = itr -> next;
    }
    itr->next = itr ->next -> next;
    return;
}


void deleteend(struct node** head){
    if((*head)==NULL ||(*head)->next==NULL ){
        (*head) = NULL;
        return;
    }
    struct node* itr = (*head);
    while(((itr -> next )-> next ) !=NULL){
        itr = itr -> next;
    }
    itr->next = NULL;
    return;
}



int main(){

    struct node* head = NULL;

    int choice,val;
    while (1) {
                        printf("\nMenu:\n");
                        printf("1.insert at beginning\n");
                        printf("2.insert at end\n");
                        printf("3.insert after node\n");
                        printf("4.delete from beginning\n");
                        printf("5.delete from end\n");
                        printf("6.delete node\n");
                        printf("7. Print  list\n");
                        printf("8. Exit\n");
                        printf("Enter your choice: ");
                        scanf("%d", &choice);

                        switch (choice) {
                            case 1:
                                printf("Enter value to insert: ");
                                int val;
                                scanf("%d", &val);
                                insertbegin(&head, val);
                                break;

                            case 2:
                                printf("Enter value to insert: ");
                                scanf("%d", &val);
                                insertatendsinglylinked(&head, val);
                                break;

                            case 3:
                                printf("Enter value to insert after: ");
                                int k;
                                scanf("%d", &k);
                                printf("Enter value to insert: ");
                                scanf("%d", &val);
                                insertafter(&head, k, val);
                                break;

                            case 4:
                                deletebegin(&head);
                                break;

                            case 5:
                                deleteend(&head);
                                break;

                            case 6:
                                printf("Enter value to delete: ");
                                scanf("%d", &k);
                                deleteatk(&head, k);
                                break;

                            case 7:
                                printlist(&head);
                                break;

                            case 8:
                                return 0;

                            default:
                                printf("Invalid, try again\n");
                        }
                    }


}