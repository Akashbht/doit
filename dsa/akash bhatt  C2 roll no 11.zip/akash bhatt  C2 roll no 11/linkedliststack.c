#include <stdio.h>
#include <stdlib.h>


struct node{
    int data;
    struct node* next;

};
struct stack {
    struct node* head;
    int size;
}s1;

void initialise(struct stack* s1) {
    s1->head= NULL;
    s1->size = 0;

    return ;

}

void push(struct stack *s1, int val) {
    struct node* temp = (struct node*)malloc(sizeof(struct node));
    temp ->data =val ;
    temp->next = s1->head;
    s1->head = temp;
    s1->size++;
}

int pop(struct stack *s1) {
    if(s1->size == 0){
        printf("empty stack \n");
        return 0;
    }
    int val = s1->head->data;
    s1->head = s1->head->next;
    s1->size--;
    return val;

}

void printstack(struct stack *s1) {
    if (s1->size == 0){
        printf("empty stack\n ");
        return ;

    }
    struct node* temp = s1->head;
    while(temp){
        printf("%d  \t", temp->data);
        temp= temp->next;
    }
    printf("\n");
}

int top(struct stack *s1) {
    if(s1->size == 0){
        printf("empty stack \n");
        return 0;
    }
    return s1->head->data;

}

int main() {
    struct stack s1;
    initialise(&s1);
    printstack(&s1);

    for(int i=0; i < 10; i++){
        push(&s1, i);
    }
    printstack(&s1);

    int popped = pop(&s1);
    printf("popped value %d \n",popped);
    printstack(&s1);

    printf("top = %d \n", top(&s1));

    return 0;
}


